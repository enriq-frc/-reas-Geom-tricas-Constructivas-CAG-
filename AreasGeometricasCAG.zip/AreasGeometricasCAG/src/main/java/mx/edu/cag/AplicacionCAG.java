package mx.edu.cag;

import java.awt.Dimension;
import javax.swing.*;

public final class AplicacionCAG {
    private AplicacionCAG() { }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(()->{
            try {UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());}catch(Exception ignored) { }
            JFrame ventana=new JFrame("Áreas Geométricas Constructivas · Java 2D");
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setContentPane(new PanelCAG());ventana.setMinimumSize(new Dimension(1100,710));
            ventana.pack();ventana.setLocationRelativeTo(null);ventana.setVisible(true);
        });
    }
}
