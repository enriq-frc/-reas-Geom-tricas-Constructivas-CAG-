package mx.edu.cag;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/** Interfaz con las tres operaciones del material de clase, en paralelo. */
public final class PanelCAG extends JPanel {
    private static final long serialVersionUID=1L;
    private final Controles a=new Controles("A"),b=new Controles("B");
    private final JCheckBox guias=new JCheckBox("Mostrar figuras originales",true);
    private final JComboBox<String> orden=new JComboBox<>(new String[]{"A − B","B − A"});
    private final JComboBox<String> seleccion=new JComboBox<>(new String[]{"A","B"});
    private final JLabel estado=new JLabel(" ");
    private final JLabel tituloDiferencia=new JLabel();
    private final Lienzo union=new Lienzo(Geometria.Operacion.UNION);
    private final Lienzo interseccion=new Lienzo(Geometria.Operacion.INTERSECCION);
    private final Lienzo diferencia=new Lienzo(Geometria.Operacion.DIFERENCIA);
    private boolean ajustando;
    public PanelCAG() {
        super(new BorderLayout(14,16));
        setBackground(new Color(242,245,249));setBorder(new EmptyBorder(22,22,16,22));
        JPanel superior=new JPanel();superior.setOpaque(false);superior.setLayout(new BoxLayout(superior,BoxLayout.Y_AXIS));
        JLabel titulo=new JLabel("Áreas Geométricas Constructivas (CAG)");
        titulo.setFont(new Font("SansSerif",Font.BOLD,26));titulo.setForeground(new Color(24,49,83));
        titulo.setAlignmentX(LEFT_ALIGNMENT);superior.add(titulo);superior.add(Box.createVerticalStrut(6));
        JLabel subtitulo=new JLabel("Construye nuevas figuras mediante unión, intersección y diferencia.");
        subtitulo.setAlignmentX(LEFT_ALIGNMENT);superior.add(subtitulo);superior.add(Box.createVerticalStrut(16));
        superior.add(a);superior.add(Box.createVerticalStrut(7));superior.add(b);
        JPanel herramientas=new JPanel(new FlowLayout(FlowLayout.LEFT,12,7));herramientas.setOpaque(false);herramientas.setAlignmentX(LEFT_ALIGNMENT);
        guias.setOpaque(false);herramientas.add(guias);herramientas.add(new JLabel("Diferencia:"));herramientas.add(orden);
        herramientas.add(new JLabel("Prioridad al arrastrar:"));herramientas.add(seleccion);
        JButton reset=new JButton("Restablecer ejemplo");reset.addActionListener(e->restablecer());herramientas.add(reset);
        superior.add(Box.createVerticalStrut(5));superior.add(herramientas);add(superior,BorderLayout.NORTH);
        JPanel comparacion=new JPanel(new GridLayout(1,3,14,0));comparacion.setOpaque(false);
        comparacion.add(tarjeta(new JLabel("Unión (A ∪ B)"),"Combina las dos figuras.",union));
        comparacion.add(tarjeta(new JLabel("Intersección (A ∩ B)"),"Conserva únicamente la parte común.",interseccion));
        comparacion.add(tarjeta(tituloDiferencia,"Resta una figura de la otra.",diferencia));
        add(comparacion,BorderLayout.CENTER);
        JPanel pie=new JPanel(new GridLayout(2,1,0,5));pie.setOpaque(false);
        pie.add(new JLabel("Arrastra una figura en cualquiera de las vistas; las tres se actualizan juntas."));
        estado.setForeground(new Color(52,77,110));pie.add(estado);add(pie,BorderLayout.SOUTH);
        guias.addActionListener(e->actualizar());orden.addActionListener(e->actualizar());
        restablecer();
    }
    private JPanel tarjeta(JLabel titulo,String detalle,Lienzo lienzo) {
        JPanel p=new JPanel(new BorderLayout(0,10));p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(216,224,235)),new EmptyBorder(16,14,12,14)));
        titulo.setFont(new Font("SansSerif",Font.BOLD,18));
        JPanel encabezado=new JPanel(new GridLayout(2,1,0,6));encabezado.setOpaque(false);encabezado.add(titulo);encabezado.add(new JLabel(detalle));
        p.add(encabezado,BorderLayout.NORTH);p.add(lienzo,BorderLayout.CENTER);
        JLabel leyenda=new JLabel("Azul: área resultante");leyenda.setForeground(new Color(30,111,165));p.add(leyenda,BorderLayout.SOUTH);return p;
    }
    private void restablecer() {
        ajustando=true;
        a.poner(Geometria.Tipo.CÍRCULO,65,70,170,170);
        b.poner(Geometria.Tipo.RECTÁNGULO,135,105,150,150);
        guias.setSelected(true);orden.setSelectedIndex(0);seleccion.setSelectedIndex(0);
        ajustando=false;actualizar();
    }
    private void actualizar() {
        if(ajustando)return;
        ajustando=true;a.normalizar();b.normalizar();ajustando=false;
        tituloDiferencia.setText("Diferencia ("+orden.getSelectedItem()+")");
        boolean vacia=Geometria.operar(a.forma(),b.forma(),Geometria.Operacion.INTERSECCION,false).isEmpty();
        estado.setText(vacia?"Las figuras no comparten área: la intersección está vacía.":"Las figuras comparten área. Observa cómo cambia cada resultado.");
        union.repaint();interseccion.repaint();diferencia.repaint();
    }
    private final class Controles extends JPanel {
        private static final long serialVersionUID=1L;
        final JComboBox<Geometria.Tipo> tipo=new JComboBox<>(Geometria.Tipo.values());
        final JSpinner x=numero(0,360),y=numero(0,290),ancho=numero(40,220),alto=numero(40,220);
        Controles(String nombre) {
            super(new FlowLayout(FlowLayout.LEFT,9,7));setAlignmentX(LEFT_ALIGNMENT);
            setBackground(Color.WHITE);setBorder(BorderFactory.createLineBorder(new Color(216,224,235)));
            JLabel letra=new JLabel("Figura "+nombre);letra.setFont(letra.getFont().deriveFont(Font.BOLD));add(letra);add(tipo);
            agregar("X",x);agregar("Y",y);agregar("Ancho",ancho);agregar("Alto",alto);
            tipo.addActionListener(e->actualizar());
            for(JSpinner s:new JSpinner[]{x,y,ancho,alto})s.addChangeListener(e->actualizar());
        }
        void agregar(String nombre,JSpinner s){JLabel l=new JLabel(nombre);l.setLabelFor(s);add(l);add(s);}
        int valor(JSpinner s){return ((Number)s.getValue()).intValue();}
        Geometria.Tipo tipoActual(){return (Geometria.Tipo)tipo.getSelectedItem();}
        void normalizar(){
            boolean uniforme=Geometria.uniforme(tipoActual());alto.setEnabled(!uniforme);
            if(uniforme)alto.setValue(valor(ancho));
            x.setValue(Math.min(valor(x),400-valor(ancho)));y.setValue(Math.min(valor(y),330-valor(alto)));
        }
        Shape forma(){return Geometria.figura(tipoActual(),valor(x),valor(y),valor(ancho),valor(alto));}
        void poner(Geometria.Tipo t,int px,int py,int w,int h){tipo.setSelectedItem(t);x.setValue(px);y.setValue(py);ancho.setValue(w);alto.setValue(h);}
        void mover(int px,int py){
            ajustando=true;x.setValue(Math.max(0,Math.min(400-valor(ancho),px)));y.setValue(Math.max(0,Math.min(330-valor(alto),py)));ajustando=false;actualizar();
        }
    }
    private static JSpinner numero(int min,int max){
        JSpinner s=new JSpinner(new SpinnerNumberModel(min,min,max,5));s.setPreferredSize(new Dimension(68,28));
        JSpinner.NumberEditor editor=new JSpinner.NumberEditor(s,"0");s.setEditor(editor);
        editor.getTextField().setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);return s;
    }
    private final class Lienzo extends JPanel {
        private static final long serialVersionUID=1L;
        private final Geometria.Operacion operacion;
        private Controles arrastrando;private double dx,dy;
        Lienzo(Geometria.Operacion operacion){
            this.operacion=operacion;setBackground(Color.WHITE);setPreferredSize(new Dimension(310,340));
            MouseAdapter raton=new MouseAdapter(){
                public void mousePressed(MouseEvent e){
                    Point2D p=punto(e);Controles primera=seleccion.getSelectedIndex()==0?a:b,segunda=primera==a?b:a;
                    arrastrando=primera.forma().contains(p)?primera:segunda.forma().contains(p)?segunda:null;
                    if(arrastrando!=null){dx=p.getX()-arrastrando.valor(arrastrando.x);dy=p.getY()-arrastrando.valor(arrastrando.y);setCursor(Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));}
                }
                public void mouseDragged(MouseEvent e){if(arrastrando!=null){Point2D p=punto(e);arrastrando.mover((int)Math.round(p.getX()-dx),(int)Math.round(p.getY()-dy));}}
                public void mouseReleased(MouseEvent e){arrastrando=null;setCursor(Cursor.getDefaultCursor());}
            };
            addMouseListener(raton);addMouseMotionListener(raton);
        }
        double escala(){return Math.max(.01,Math.min((getWidth()-12)/400.0,(getHeight()-28)/330.0));}
        Point2D punto(MouseEvent e){double s=escala();return new Point2D.Double((e.getX()-(getWidth()-400*s)/2)/s,(e.getY()-(getHeight()-330*s)/2)/s);}
        @Override protected void paintComponent(Graphics original){
            super.paintComponent(original);Graphics2D g=(Graphics2D)original.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            double s=escala();g.translate((getWidth()-400*s)/2,(getHeight()-330*s)/2);g.scale(s,s);
            Shape fa=a.forma(),fb=b.forma();Area resultado=Geometria.operar(fa,fb,operacion,orden.getSelectedIndex()==1);
            g.setColor(new Color(51,153,215));g.fill(resultado);
            g.setStroke(new BasicStroke((float)(1.5/s)));g.setColor(new Color(31,92,130));g.draw(resultado);
            if(guias.isSelected()){
                g.setColor(new Color(62,77,94));g.setStroke(new BasicStroke((float)(1.7/s)));g.draw(fa);
                g.setStroke(new BasicStroke((float)(1.7/s),BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,10,new float[]{(float)(6/s),(float)(3/s)},0));g.draw(fb);
                g.setFont(new Font("SansSerif",Font.BOLD,16));
                g.drawString("A",a.valor(a.x)+5,Math.max(16,a.valor(a.y)-8));
                g.drawString("B",b.valor(b.x)+b.valor(b.ancho)-14,Math.min(328,b.valor(b.y)+b.valor(b.alto)+20));
            }
            if(resultado.isEmpty()){
                g.setColor(new Color(112,122,139));g.setFont(new Font("SansSerif",Font.PLAIN,15));g.drawString("Resultado vacío",140,318);
            }
            g.dispose();
        }
    }
}
