package mx.edu.cag;

import java.awt.Shape;
import java.awt.geom.*;

/** Operaciones CAG reales sobre áreas vectoriales de Java 2D. */
public final class Geometria {
    public enum Tipo { CÍRCULO, RECTÁNGULO, ELIPSE, CUADRADO, TRIÁNGULO, HEXÁGONO }
    public enum Operacion { UNION, INTERSECCION, DIFERENCIA }
    private Geometria() { }
    public static Shape figura(Tipo tipo,double x,double y,double ancho,double alto) {
        return switch(tipo) {
            case CÍRCULO -> new Ellipse2D.Double(x,y,ancho,ancho);
            case ELIPSE -> new Ellipse2D.Double(x,y,ancho,alto);
            case RECTÁNGULO -> new Rectangle2D.Double(x,y,ancho,alto);
            case CUADRADO -> new Rectangle2D.Double(x,y,ancho,ancho);
            case TRIÁNGULO -> poligono(x,y,ancho,3);
            case HEXÁGONO -> poligono(x,y,ancho,6);
        };
    }
    public static boolean uniforme(Tipo tipo) {
        return tipo!=Tipo.ELIPSE && tipo!=Tipo.RECTÁNGULO;
    }
    private static Shape poligono(double x,double y,double diametro,int lados) {
        Path2D p=new Path2D.Double(); double r=diametro/2;
        for(int i=0;i<lados;i++) {
            double angulo=-Math.PI/2+i*2*Math.PI/lados;
            double px=x+r+r*Math.cos(angulo),py=y+r+r*Math.sin(angulo);
            if(i==0)p.moveTo(px,py);else p.lineTo(px,py);
        }
        p.closePath();return p;
    }
    public static Area operar(Shape a,Shape b,Operacion operacion,boolean invertir) {
        // Cada resultado usa copias; las figuras originales nunca se alteran.
        Area resultado=new Area(invertir && operacion==Operacion.DIFERENCIA?b:a);
        Area segundo=new Area(invertir && operacion==Operacion.DIFERENCIA?a:b);
        switch(operacion) {
            case UNION -> resultado.add(segundo);
            case INTERSECCION -> resultado.intersect(segundo);
            case DIFERENCIA -> resultado.subtract(segundo);
        }
        return resultado;
    }
}
